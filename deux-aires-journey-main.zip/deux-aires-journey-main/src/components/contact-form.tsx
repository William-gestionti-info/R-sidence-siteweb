import { useState, type FormEvent } from "react";
import { CheckCircle2 } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";

export function ContactForm() {
  const [sent, setSent] = useState(false);
  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    if (!form.checkValidity()) return;
    setSent(true);
    form.reset();
  }
  if (sent) return <div className="grid min-h-96 place-items-center rounded-3xl bg-secondary p-8 text-center"><div><CheckCircle2 className="mx-auto size-12 text-primary" /><h2 className="mt-5 text-3xl font-semibold">Merci pour votre demande</h2><p className="mt-3 max-w-md text-muted-foreground">Notre équipe communiquera avec vous prochainement afin de répondre à vos questions et de planifier la suite.</p><Button variant="warm" className="mt-6" onClick={() => setSent(false)}>Envoyer une autre demande</Button></div></div>;
  return <form onSubmit={submit} className="grid gap-5 rounded-3xl bg-card p-6 shadow-xl shadow-foreground/5 md:p-9" aria-label="Formulaire de demande d'information"><div className="grid gap-5 sm:grid-cols-2"><div className="space-y-2"><Label htmlFor="name">Nom complet *</Label><Input id="name" name="name" required maxLength={100} autoComplete="name" className="h-12" /></div><div className="space-y-2"><Label htmlFor="phone">Téléphone *</Label><Input id="phone" name="phone" type="tel" required maxLength={25} autoComplete="tel" className="h-12" /></div></div><div className="grid gap-5 sm:grid-cols-2"><div className="space-y-2"><Label htmlFor="email">Courriel *</Label><Input id="email" name="email" type="email" required maxLength={255} autoComplete="email" className="h-12" /></div><div className="space-y-2"><Label htmlFor="relation">Je cherche pour…</Label><select id="relation" name="relation" className="h-12 w-full rounded-md border border-input bg-transparent px-3 text-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"><option>Moi-même</option><option>Un parent ou un proche</option><option>Autre</option></select></div></div><div className="space-y-2"><Label htmlFor="message">Comment pouvons-nous vous aider? *</Label><Textarea id="message" name="message" required maxLength={1500} rows={5} placeholder="Disponibilités, services recherchés, souhait de visite…" /></div><label className="flex items-start gap-3 text-xs leading-5 text-muted-foreground"><input type="checkbox" required className="mt-1 accent-primary" />J’accepte d’être contacté(e) au sujet de ma demande. Mes renseignements seront utilisés uniquement pour y répondre.</label><Button type="submit" variant="hero" size="lg" className="w-full sm:w-fit">Recevoir de l’information</Button><p className="text-xs text-muted-foreground">Vous préférez parler à quelqu’un? Appelez-nous au <a className="font-bold text-primary" href="tel:+15143331515">514 333-1515</a>.</p></form>;
}