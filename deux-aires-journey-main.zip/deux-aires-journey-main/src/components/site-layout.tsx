import { Link } from "@tanstack/react-router";
import { Heart, Menu, Phone, X } from "lucide-react";
import { useState } from "react";
import { Button } from "./ui/button";

const nav = [
  { to: "/", label: "Accueil" },
  { to: "/a-propos", label: "À propos" },
  { to: "/services", label: "Services" },
  { to: "/contact", label: "Contact" },
] as const;

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-50 border-b border-border/70 bg-background/90 backdrop-blur-xl">
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-5 lg:px-8">
        <Link to="/" className="flex items-center gap-3" aria-label="Résidence Les Deux Aires — Accueil">
          <span className="grid size-11 place-items-center rounded-full bg-primary text-primary-foreground"><Heart className="size-5" /></span>
          <span className="leading-none"><strong className="block font-display text-xl text-foreground">Les Deux Aires</strong><small className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground">Résidence privée</small></span>
        </Link>
        <nav className="hidden items-center gap-8 lg:flex" aria-label="Navigation principale">
          {nav.map((item) => <Link key={item.to} to={item.to} activeProps={{ className: "text-primary" }} className="text-sm font-semibold text-foreground/75 transition-colors hover:text-primary">{item.label}</Link>)}
        </nav>
        <div className="hidden items-center gap-3 lg:flex">
          <a href="tel:+15143331515" className="flex items-center gap-2 text-sm font-semibold"><Phone className="size-4 text-primary" />514 333-1515</a>
          <Button asChild variant="hero"><Link to="/contact">Planifier une visite</Link></Button>
        </div>
        <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setOpen((value) => !value)} aria-label="Ouvrir le menu">{open ? <X /> : <Menu />}</Button>
      </div>
      {open && <nav className="border-t border-border bg-background px-5 py-5 lg:hidden">{nav.map((item) => <Link key={item.to} to={item.to} onClick={() => setOpen(false)} className="block py-3 text-lg font-semibold">{item.label}</Link>)}<Button asChild variant="hero" className="mt-3 w-full"><Link to="/contact" onClick={() => setOpen(false)}>Planifier une visite</Link></Button></nav>}
    </header>
  );
}

export function SiteFooter() {
  return <footer className="bg-foreground text-background"><div className="mx-auto grid max-w-7xl gap-10 px-5 py-14 md:grid-cols-3 lg:px-8"><div><p className="font-display text-3xl">Les Deux Aires</p><p className="mt-3 max-w-sm text-sm text-background/70">Un chez-soi accueillant, sécuritaire, chaleureux et stimulant à Ahuntsic, au bord de la rivière des Prairies.</p></div><div><p className="font-semibold">Nous joindre</p><address className="mt-3 space-y-2 text-sm not-italic text-background/70"><p>505, boul. Gouin Ouest<br />Montréal (Québec) H3L 3T2</p><p><a href="tel:+15143331515">514 333-1515</a></p><p><a href="mailto:info@lesdeuxaires.com">info@lesdeuxaires.com</a></p></address></div><div><p className="font-semibold">Découvrir</p><div className="mt-3 flex flex-col gap-2 text-sm text-background/70">{nav.map((item) => <Link key={item.to} to={item.to}>{item.label}</Link>)}</div></div></div><div className="border-t border-background/15 px-5 py-5 text-center text-xs text-background/55">© {new Date().getFullYear()} Résidence Les Deux Aires. Tous droits réservés.</div></footer>;
}

export function PageHero({ eyebrow, title, description }: { eyebrow: string; title: string; description: string }) {
  return <section className="relative overflow-hidden bg-foreground py-24 text-background"><div className="absolute -right-20 -top-40 size-96 rounded-full border border-background/15 orbit-soft" /><div className="absolute right-24 top-10 size-64 rounded-full border border-sage/40" /><div className="relative mx-auto max-w-7xl px-5 lg:px-8"><p className="mb-5 text-xs font-bold uppercase tracking-[0.25em] text-sage">{eyebrow}</p><h1 className="max-w-4xl text-balance text-5xl font-semibold leading-[0.95] md:text-7xl">{title}</h1><p className="mt-7 max-w-2xl text-lg leading-8 text-background/75">{description}</p></div></section>;
}