import { Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { Button } from "./ui/button";

export function CtaBand() {
  return <section className="bg-primary py-16 text-primary-foreground"><div className="mx-auto flex max-w-7xl flex-col items-start justify-between gap-7 px-5 md:flex-row md:items-center lg:px-8"><div><p className="text-xs font-bold uppercase tracking-[0.25em] text-primary-foreground/65">Venez ressentir l’atmosphère</p><h2 className="mt-3 max-w-2xl text-4xl font-semibold md:text-5xl">Votre prochain chez-vous mérite une visite.</h2></div><Button asChild variant="warm" size="lg"><Link to="/contact">Planifier une visite <ArrowRight /></Link></Button></div></section>;
}